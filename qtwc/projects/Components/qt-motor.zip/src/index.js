import "./styles.css";

/*const motor = document.createElement("qt-motor");
document.body.appendChild(motor);*/
