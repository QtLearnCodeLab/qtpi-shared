/*  Change your comport number only
    Connect APDS sensor to port 1, 
*/

//var b = //p5.board('/dev/rfcomm56',',connectCb,disconnectCb);
var b = p5.board('COM3','arduino',connectCb,disconnectCb);
var apds_pin1;
var temp = 22;
var thermometer = new Thermometer();


function connectCb() {
  console.log("connected");
  apds_pin1 = b.pin(20, 'DIGITAL', 'OUTPUT');
}

function disconnectCb() {
  console.log("disconnected");
}


function dataCb(data) {
  //console.log(data);
  json_data = JSON.parse(data);
  if(json_data.name == "MPU6050"){
   console.log(json_data.temp); 
    temp = json_data.temp.temp;
    thermometer.setCurrentValue(temp);
    var url = "https://api.thingspeak.com/update?api_key=1PBMOAAB4BYQA6PD&field1="+temp;
    console.log(temp,url);
    fetch(url).then(response => response.json())
      .then(data_response => console.log(data_response));
  }
}

function enable() {
  console.log("initialize clicked");
  var arr = [0x1A,0x26,0x00];
  apds_pin1.sendSysex(arr,dataCb);
}

function disable() {
  console.log("initialize clicked");
  var arr = [0x1A,0x26,0x01];
  apds_pin1.sendSysex(arr);
}

function setup() {
 
  var button_enable = createButton('enable');
  button_enable.position(200, 200);
  button_enable.mouseClicked(function(){enable()});
  var button_disable = createButton('disable');
  button_disable.position(300, 200);
  button_disable.mouseClicked(function(){disable()});
  createCanvas(400, 400);
  background(128);
  textSize(32);


  var container = document.getElementById('container');
  thermometer.render(container, 22, 15, 40);

}

function draw() {
  clear();
  textSize(32);
  text("Temperature:  "+temp, 10, 60); 
}

