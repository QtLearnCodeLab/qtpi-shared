#!/usr/bin/env node
/*jshint esversion: 6 */
'use strict';

var express = require('express'),
  app = express(),
  cors = require('cors'),
  server = require('http').Server(app),
  io = require('socket.io')(server, {
    cors: {
      origin: '*',
    },
    jsonp: false,
    transports: ['polling', 'websocket']
  }),
  Board = require('firmata'),
  program = require('commander'),
  fs = require('fs'),
  path = require('path');

// Parse command-line args
var directory, index, program;
var serial = require('./lib/serial.js');
function makeAbsolute (filepath) {
  return path.isAbsolute(filepath) ? filepath : process.cwd() + '/' + filepath;
}



// This both defines options as well as what prints when '--help' is called.
program
  .description('Run `node app.js` plus these flags to configure your server.')
  .option('-d, --dir <d>', 'Set base directory for server')
  .option('-f, --file <f>', 'Set file to use for index page')
  .option('-p, --ufilepath <p>',
    'Path to file containing user-defined server-side listeners.')
  .option('-n, --ufilename <n>',
    'Path, inluding file name, to user-defined server-side listeners.');
//.parse(process.argv);

exports.program = program;
exports.directory = directory = program.dir || __dirname;
exports.index = index = program.file || (directory + '/index.html');

// Setup server, sockets, and events

server.listen(8000);
app.use(cors());
app.options('*', cors());

app.use(express.static(directory));
console.log('server started in 8000 port allowed cors *');

app.get('/', function (req, res) {
  console.log('server / request');
  res.sendFile(makeAbsolute(index));
});


// App code: Define as export for IDE, call at end of file for non-IDE usage

var setup = exports.setup = function (io) {

  var board;
  var boardMap = {};

  io.of('/sensors').on('connect', function (socket) {
    console.log('connect request on /sensors');
    exports.socket = socket;

    // Error handling

    socket.on('error', function (err) {
      console.log(err);
    });

    // Board setup

    socket.on('board object', function (data) {
      console.log('received board object', data);
      function init () {
        console.log('board object init', data);
        socket.emit('board ready', { analogArr: board.analogPins });
        initializeSpecialFuncs(board);
      }
      function deinit (data) {
        console.log('deinit from server',data);
        var boardObj = boardMap[data.port];
        if(boardObj) {
          console.log('boardObj =>',boardObj);
          boardObj.reset();
          boardObj.isReady = false;
          boardObj = null;
          delete boardMap[data.port];
        }else {
          console.log('boardObj null');
        }
        console.log('board disconnect and delete the board obj from map');
        socket.emit('board disconnect');
      }
      try {
        // If the board has already been initialized in firmata, it won't
        // call the callback again on client reload; this way the init
        // functions are called without restarting the whole proces
        var options = {
          reportVersionTimeout: 5000,
          samplingInterval: 99,
          serialport: {
            baudRate: 115200,
            // https://github.com/node-serialport/node-serialport/blob/5.0.0/UPGRADE_GUIDE.md#open-options
            highWaterMark: 256,
          },
        };
        //console.log('Board Map', boardMap, data);
        
        var boardObj = boardMap[data.port];
        console.log('Board Map ====>', Object.keys(boardMap), data.port,boardObj);
        if (!boardObj) {
          console.log('Board not present creating a Board',
            data, options, board);
          console.log('print port array', serial.portsArr);
          board = new Board(data.port, options);
        } else {
          console.log('Board already present initializing');
          init();
        }
        board.on('error', (err) => {
          console.log('board error event',err);
          if(err) {
            console.log('Error Msg is :',err.message);
            var errMsg = err.message.includes('No such file or directory, cannot open'); // jshint ignore:line
            if(errMsg) {
              deinit(data);
            }
          }
        });
        board.on('open', (event) => {
          console.log('board open event',event);
          console.log('Board get created and initalizing');
          boardMap[data.port] = board;
          init();
        });
        board.on('connect', (event) => {
          console.log('board connect event(legacy)',event);
        });
        board.on('ready', (event) => {
          console.log('board ready event',event);
          console.log('Board get created and initalizing');
          boardMap[data.port] = board;
          init();
        });
        board.on('string', function (str_data) {
          console.log('got str_data', str_data);
          socket.emit('sysex string', str_data);
        });

        board.on('close', function (cdata) {
          console.log('got close',cdata);
          deinit(data);

        });

        board.on('disconnect', function (cdata) {
          console.log('got disconnect',cdata);
          deinit(data);
        });
      } catch (error) {
        console.log('Error ', error);
      }

    });

    // Pin setup

    socket.on('pin object', function (data) {
      console.log('received pin object', data);
      // Digital pins are set to INPUT or OUTPUT in firmata
      data.mode === 'digital' ?
        board.pinMode(data.pin, board.MODES[data.direction.toUpperCase()]) :
        board.pinMode(data.pin, board.MODES[data.mode.toUpperCase()]);
    });
    // Action functions:
    // The primary action function formats the read & write functions & sends
    // these to firmata
    socket.on('action', function (data) {
      console.log('action data', data);
      var argument = data.arg;
      if (data.type === 'send_sysex') {
        console.log('sending sysex command', argument, typeof (argument));
        board.sysexCommand(argument); //without START_SYSEX and END_SYSEX
      } else if (argument || data.type === 'write') {
        // If it is digtalWrite, augment the argument with
        // `board` to match firmata call
        if (argument && (argument === 'HIGH' || argument === 'LOW')) {
          board[data.action](data.pin, board[argument]);
        } else {
          board[data.action](data.pin, argument);
        }
        // Otherwise it is read with no argument, set pin.val on update
      } else if (data.type === 'read') {
        board[data.action](data.pin, function (val) {
          socket.emit('return val' + data.pin, { val: val });
        });
      }
    });
    // Special functions
    function initializeSpecialFuncs (board) {
      try {


        console.log('initializeSpecialFuncs firmata object as  board');

        console.log('initializing RGB');
        // LED
        var led = require('./lib/led.js');
        led.blink(board, socket);
        led.fade(board, socket);

        console.log('initializing RGB');
        // RGB
        var rgb = require('./lib/rgb.js');
        rgb.write(board, socket);
        rgb.read(board, socket);
        rgb.blink(board, socket);
        rgb.fade(board, socket);

        console.log('initializing Servo');
        // Servo
        var servo = require('./lib/servo.js');
        servo.range(board, socket);
        servo.sweep(board, socket);

        console.log('initializing piezo');
        // Piezo
        var piezo = require('./lib/piezo.js');
        piezo.tone(board, socket);

        console.log('initializing ports');
        // ports
        var ports = require('./lib/ports.js');
        ports.ports(board, socket);

        // User defined, if present

        var filepath;

        if (program.ufilename) {
          filepath = program.ufilename;
        } else if (program.ufilepath) {
          var userpath = program.ufilepath || __dirname;
          filepath = userpath + '/user.js';
        }

        if (filepath) {
          filepath = path.normalize(filepath);
          fs.stat(filepath, function (err, stats) {
            if (err == null) {

              var reqPath = makeAbsolute(filepath);

              var user = require(reqPath),
                keys = Object.keys(user);

              keys.forEach(function (key) {
                user[key](board, socket);
              });

            } else if (err.code === 'ENOENT') {
              throw new Error(filepath +
                ' does not seem to exist. Maybe it is a ghost.');

            } else {
              console.log(err);
            }
          });
        }
      } catch (error) {
        console.log('Error ocurred in initialization ', error);
      }

    }

    // Serial does not require firmata board
    serial.init(socket);
    serial.close(socket);
    serial.read(socket);
    serial.write(socket);
    console.log('list serial object ');
    serial.list(socket);

  });
};
console.log('calling setup method');
setup(io);