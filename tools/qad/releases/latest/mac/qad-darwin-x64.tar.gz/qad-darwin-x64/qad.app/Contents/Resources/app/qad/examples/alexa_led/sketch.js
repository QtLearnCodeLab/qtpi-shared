/* Only change the comport number
  Connect LED to port 3 
*/
let counter =0;
let url = "https://io.adafruit.com/api/v2/simran190212/feeds/led" //add your own Feed URL
var b = p5.board('COM3', 'arduino',connectCb,disconnectCb);
var LED;

function connectCb() {
  console.log("connected");
}

function disconnectCb() {
  console.log("disconnected");
}

function checkFlag() {
  if (b.ready == false) {
    console.log("waiting ...");
    setTimeout(checkFlag, 1000);
  } else {
    console.log("board is connected and ready ...");
    console.log("board is ready ");
  }
}

function setup() {
  checkFlag();
  var button_on = createButton('Turn ON');
  var button_off = createButton('Turn OFF');
  button_on.position(200, 200);
  button_off.position(200, 250);

  
}
function draw(){}
  let data;
  var pin = b.pin(10, 'DIGITAL', 'OUTPUT');
  if (counter % 100 == 0) {
    httpGet(url, 'json', function(response) {
      console.log(response);
      data = response.last_value;
      console.log(data)
      if(data == "ON"){
        console.log("ON", data);
        pin.write('HIGH');
      }
      else if(data == "OFF"){
        console.log("OFF",data);
        pin.write('LOW');
      }
    });
  }
  counter++;
}

