# For install
npm i
# For running
node ./node_modules/.bin/bots-go -d './node_modules/qad-server/example'

#for testing
Modify the qtpi_veda.js with correct COM port and enable are disable blocks of specific test and run the "./node_modules/.bin/bots-go -d './node_modules/qad-server/example'" command

# make qad.js
npm i; grunt
