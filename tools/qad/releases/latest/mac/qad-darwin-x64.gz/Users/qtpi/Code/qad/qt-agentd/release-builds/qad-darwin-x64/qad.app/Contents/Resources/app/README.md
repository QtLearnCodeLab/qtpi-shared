# QAD Qt Agent Daemon server and client libraries

GUI (Electron) application for use with [qad]

Runs and controls p5.bots (no need to install and run it separately)


## OSX Development
**Install dependencies**

1.  `npm install`
2.  `npm run rebuild`
3.  `npm run package-mac`
4.  `npm start` # just to validate

## Windows Development
**Install dependencies**

1.  `npm install`
2.  `npm run rebuild`
3.  `npm run package-win`
4.  `npm start` # just to validate

## Linux Development
**Install dependencies**

1.  `npm install`
2.  `npm run rebuild`
3.  `npm run package-linux`
4.  `npm start` # just to validate

**Rebuild serialport library (more on this [here](https://stackoverflow.com/questions/40254287/electron-and-serial-ports))** if needed
