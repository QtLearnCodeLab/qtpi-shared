function setup() {
    createCanvas(400, 400);
  }
  
  let counter =0;
  let url = "	https://io.adafruit.com/api/v2/simran190212/feeds/fan" //add your own feed URL
  var b = p5.board('COM3', 'arduino',connectCb,disconnectCb);
  
  
  function connectCb() {
    console.log("connected");
  }
  
  function disconnectCb() {
    console.log("disconnected");
  }
  
  function checkFlag() {
    if (b.ready == false) {
      console.log("waiting ...");
      setTimeout(checkFlag, 1000);
    } else {
      console.log("board is connected and ready ...");
      console.log("board is ready ");
    }
  }
  
  function setup() {
    checkFlag();  
  }
  function draw(){
    var pin1 = b.pin(4, 'PWM', 'OUTPUT');
    if (counter % 100 == 0) {
      httpGet(url, 'json', function(response) {
        console.log(response);
        data = response.last_value;
        console.log(data)
        if(data == "ON"){
          console.log("ON", data);
          pin1.write(200);      
        }
        else if(data == "OFF"){
          console.log("OFF",data);
          pin1.write(0);
        }
      });
    }
    counter++;
  }
  
  