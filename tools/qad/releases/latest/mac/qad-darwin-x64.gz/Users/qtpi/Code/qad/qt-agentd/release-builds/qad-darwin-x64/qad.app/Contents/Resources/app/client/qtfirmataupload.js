/**
    QtPiFirmata Flash Utility
    Allow user to load file from local disk and url
*/
import Avrgirl as avrgirl from 'avrgirl-arduino';
import request from 'request';


export const hexFileUrl = {
    "veda": {
        "boardType": "mega",
        "latest": "https://qtlearncodelab.github.io/qtpi-shared/firmware/veda/latest/QtPiFirmataVeda.ino.hex",
        "stable": "https://qtlearncodelab.github.io/qtpi-shared/firmware/veda/stable/QtPiFirmataVeda.ino.hex"
    },
    "rio": {
        "boardType": "uno",
        "latest": "https://qtlearncodelab.github.io/qtpi-shared/firmware/rio/latest/QtPiFirmataRio.ino.hex",
        "stable": "https://qtlearncodelab.github.io/qtpi-shared/firmware/rio/stable/QtPiFirmataRio.ino.hex"
    }
};


export  function uploadHexFileUrl (board, comPort, version, debug = true) {
    let boardType = hexFileUrl[board]["boardType"];
    let url = hexFileUrl[board][version];
    console.log(boardType,board,url);
    let avrgirlObj = new avrgirl({
        board: boardType,
        port: comPort,
        manualReset: true,
        debug: debug

    });
    request.defaults({
        encoding: null
    });
    request.get(url, function (err, res, body) {
        if (!err) {
            console.log("Got Hex file");
            avrgirlObj.flash(Buffer.from(body), function (error) {
                if (error) {
                    console.error(error);
                } else {
                    console.info('done uploading.');
                }
            });
        } else {
            console.error("No hex file found" + err);
        }

    });

}
function uploadHexFileLocal (board, comPort, fPath, debug = true) {
    let boardType = hexFileUrl[board]["boardType"];
    console.log(boardType,board);
    let avrgirlObj = new avrgirl({
        board: boardType,
        port: comPort,
        manualReset: true,
        debug: debug

    });
    avrgirlObj.flash(fPath, function (error) {
        if (error) {
            console.error(error);
        } else {
            console.info('done.');
        }
    });

}


