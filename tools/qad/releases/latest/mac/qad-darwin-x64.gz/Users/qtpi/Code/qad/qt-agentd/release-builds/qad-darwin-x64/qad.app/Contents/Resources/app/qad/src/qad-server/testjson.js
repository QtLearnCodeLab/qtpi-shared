const low = require('lowdb')
const FileSync = require('lowdb/adapters/FileSync')

//const adapter = new FileSync('json/veda.json')
//const adapter = new FileSync('json/rio.json');
const adapter = new FileSync('json/veda-esp32.json')
const db = low(adapter)

db.read();

console.log(db.get('ports').get('rj').get('analogPins').value());
console.log(
db.get('ports').get('rj').get('analogPins')
  .filter({'port':1})
  .value());

console.log(
  db.get('ports').get('motor')
  .filter({'port':2})
  .value());

console.log(db.get('ports').value());