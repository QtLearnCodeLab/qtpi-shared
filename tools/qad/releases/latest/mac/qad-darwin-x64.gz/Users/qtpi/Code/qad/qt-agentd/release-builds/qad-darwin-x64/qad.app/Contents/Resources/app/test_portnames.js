let sp = require('serialport');
sp.list().then(ports => {
  let portsArr = [];
  ports.forEach(function(port) {
    var inner = {};
    inner.portName = port.path;
    inner.pnpId = port.pnpId;
    inner.manufacturer = port.manufacturer;
    portsArr.push(inner);
    console.log(" return", port);
  });
  
  
});
